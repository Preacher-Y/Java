public class Books {
    public int id;
    public String title;
    public int days;

    public Books(int id, String title, int days) {
        this.id = id;
        this.title = title;
        this.days = days;
    }
}